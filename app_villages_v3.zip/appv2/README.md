# 🗺️ Villages & Quartiers Bénin — v3 (Optimisée + En ligne)

## ▶️ UTILISATION LOCALE (Windows/Mac)

### 1. Installer les dépendances (une seule fois)
```
pip install flask openpyxl gunicorn werkzeug
```

### 2. Lancer l'application
Ouvrir un terminal dans ce dossier puis :
```
python app.py
```
Aller sur → **http://localhost:5000**

---

## 🌐 MISE EN LIGNE SUR RAILWAY (accès Android/iPhone/partout)

### Étape 1 — Créer un compte gratuit
→ https://railway.app  (connexion avec GitHub)

### Étape 2 — Créer un compte GitHub (si pas encore fait)
→ https://github.com

### Étape 3 — Uploader ce dossier sur GitHub
1. Aller sur https://github.com/new
2. Créer un dépôt (ex: `villages-benin`)
3. Uploader tous les fichiers de ce dossier

### Étape 4 — Déployer sur Railway
1. Sur railway.app → "New Project"
2. Choisir "Deploy from GitHub repo"
3. Sélectionner ton dépôt `villages-benin`
4. Railway détecte automatiquement Python et lance l'app
5. Cliquer sur "Generate Domain" → tu obtiens un lien public

### Résultat
Tu obtiens une URL du type :
**https://villages-benin-xxxx.railway.app**

Accessible depuis n'importe quel appareil ! 🎉

---

## ⚡ AMÉLIORATIONS v3 vs v2

| | v2 | v3 |
|---|---|---|
| Recherche village | ~2s | <0.001s (SQLite) |
| Index | Reconstruit à chaque fichier | Construit 1x au démarrage |
| Multi-appareils | Non | Oui (Railway) |
| Android/iPhone | Non | Oui |

---

## 📁 FICHIERS

```
appv2/
├── app.py           ← Application principale
├── mere.xlsx        ← Fichier mère (NE PAS SUPPRIMER)
├── log.json         ← Historique
├── requirements.txt ← Dépendances Python
├── Procfile         ← Config Railway
├── railway.json     ← Config Railway
├── templates/
│   └── index.html   ← Interface web
└── README.md
```
